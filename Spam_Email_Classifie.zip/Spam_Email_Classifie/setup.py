"""
Setup script to install required packages
"""

import subprocess
import sys

def install_packages():
    """Install required packages from requirements.txt"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("Successfully installed required packages!")
    except subprocess.CalledProcessError as e:
        print(f"Error installing packages: {e}")
        return False
    return True

def main():
    print("Installing required packages...")
    success = install_packages()
    if success:
        print("Setup completed successfully!")
    else:
        print("Setup failed. Please install packages manually using: pip install -r requirements.txt")

if __name__ == "__main__":
    main()