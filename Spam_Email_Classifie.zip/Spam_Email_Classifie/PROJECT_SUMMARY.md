# Spam Email Classifier - Project Summary

## Overview
This project implements a spam email classifier using Natural Language Processing (NLP) and Machine Learning. It uses the Naive Bayes algorithm with TF-IDF feature extraction to classify emails as either "Spam" or "Ham" (not spam).

## Project Structure
```
Spam_Email_Classifier/
│
├── data/
│   └── spam_emails.csv (dataset)
│
├── notebooks/
│   └── spam_email_classifier.ipynb (Jupyter notebook implementation)
│
├── models/
│   ├── naive_bayes_model.pkl (trained model)
│   └── vectorizer.pkl (TF-IDF vectorizer)
│
├── images/
│   └── confusion_matrix.png (visualization)
│
├── results/
│   └── evaluation_metrics.txt (model performance metrics)
│
├── README.md
├── requirements.txt
├── spam_classifier.py (main Python script)
├── run_classifier.py (command-line interface)
└── setup.py (installation script)
```

## How to Use

### Option 1: Run the complete pipeline
```bash
python spam_classifier.py
```

### Option 2: Use the command-line interface to classify individual emails
```bash
python run_classifier.py "Your email text here"
```

Example:
```bash
python run_classifier.py "Congratulations! You won a free prize. Click now."
```

### Option 3: Use the Jupyter notebook
Start Jupyter:
```bash
jupyter notebook
```
Then open `notebooks/spam_email_classifier.ipynb`

## Installation
All required packages are listed in `requirements.txt`. Install them with:
```bash
pip install -r requirements.txt
```

Or run the setup script:
```bash
python setup.py
```

## Model Performance
- Algorithm: Multinomial Naive Bayes
- Accuracy: ~98.84%
- Precision (Ham): 98%
- Recall (Ham): 100%
- Precision (Spam): 100%
- Recall (Spam): 97%

## Key Features
- Text preprocessing with tokenization, stop-word removal, and stemming
- TF-IDF feature extraction for converting text to numerical vectors
- Model persistence (saves trained model and vectorizer)
- Comprehensive evaluation metrics
- Command-line interface for easy predictions

## Files Generated
- Trained model saved as `models/naive_bayes_model.pkl`
- TF-IDF vectorizer saved as `models/vectorizer.pkl`
- Evaluation metrics saved as `results/evaluation_metrics.txt`
- Confusion matrix visualization saved as `images/confusion_matrix.png`

## Technologies Used
- Python
- Pandas (data manipulation)
- NumPy (numerical computations)
- NLTK (natural language processing)
- Scikit-learn (machine learning)
- Matplotlib/Seaborn (visualization)
- Pickle (model serialization)