"""
Test script to verify the spam email classifier is working properly
"""

import os
import sys
import pickle
import pandas as pd

def test_project_structure():
    """Test if all required directories and files exist"""
    print("Testing project structure...")
    
    dirs_to_check = ['data', 'notebooks', 'models', 'images', 'results']
    files_to_check = [
        'data/spam_emails.csv',
        'notebooks/spam_email_classifier.ipynb', 
        'models/naive_bayes_model.pkl',
        'models/vectorizer.pkl',
        'images/confusion_matrix.png',
        'results/evaluation_metrics.txt',
        'requirements.txt',
        'README.md',
        'spam_classifier.py',
        'run_classifier.py'
    ]
    
    all_good = True
    
    for directory in dirs_to_check:
        if not os.path.isdir(directory):
            print(f"❌ Directory missing: {directory}")
            all_good = False
        else:
            print(f"✅ Directory exists: {directory}")
    
    for file in files_to_check:
        if not os.path.isfile(file):
            print(f"❌ File missing: {file}")
            all_good = False
        else:
            print(f"✅ File exists: {file}")
    
    return all_good

def test_model_loading():
    """Test if the trained model can be loaded"""
    print("\nTesting model loading...")
    
    try:
        model = pickle.load(open('models/naive_bayes_model.pkl', 'rb'))
        vectorizer = pickle.load(open('models/vectorizer.pkl', 'rb'))
        print("✅ Models loaded successfully")
        print(f"✅ Model type: {type(model)}")
        print(f"✅ Vectorizer type: {type(vectorizer)}")
        return True
    except Exception as e:
        print(f"❌ Error loading models: {e}")
        return False

def test_data_loading():
    """Test if the dataset can be loaded"""
    print("\nTesting data loading...")
    
    try:
        data = pd.read_csv('data/spam_emails.csv')
        print(f"✅ Data loaded successfully")
        print(f"✅ Data shape: {data.shape}")
        print(f"✅ Columns: {list(data.columns)}")
        return True
    except Exception as e:
        print(f"❌ Error loading data: {e}")
        return False

def test_prediction():
    """Test if predictions work"""
    print("\nTesting prediction functionality...")
    
    try:
        # Import the prediction function from the main script
        import sys
        import os
        sys.path.append(os.path.dirname(os.path.abspath(__file__)))
        
        from spam_classifier import predict_email
        
        # Test a spam email
        spam_result, spam_confidence = predict_email("Congratulations! You won a free prize. Click now.")
        print(f"✅ Spam test: '{spam_result}' (confidence: {spam_confidence:.2f})")
        
        # Test a ham email
        ham_result, ham_confidence = predict_email("Hi, can we meet for lunch tomorrow?")
        print(f"✅ Ham test: '{ham_result}' (confidence: {ham_confidence:.2f})")
        
        return True
    except Exception as e:
        print(f"❌ Error with prediction: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests"""
    print("🔍 Running Spam Email Classifier Verification Tests\n")
    
    tests = [
        test_project_structure,
        test_model_loading,
        test_data_loading,
        test_prediction
    ]
    
    results = []
    for test in tests:
        results.append(test())
    
    print(f"\n📊 Test Results: {sum(results)}/{len(results)} passed")
    
    if all(results):
        print("🎉 All tests passed! The spam email classifier is working properly.")
        print("\nYou can now use the classifier in the following ways:")
        print("1. Run the full pipeline: python spam_classifier.py")
        print("2. Classify individual emails: python run_classifier.py \"Your email text\"")
        print("3. Use the Jupyter notebook: jupyter notebook notebooks/spam_email_classifier.ipynb")
    else:
        print("❌ Some tests failed. Please check the error messages above.")

if __name__ == "__main__":
    main()