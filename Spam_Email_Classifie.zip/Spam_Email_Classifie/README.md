# Spam Email Classifier

## Overview
This project builds a Machine Learning model that classifies emails as **Spam** or **Not Spam (Ham)** using **Natural Language Processing (NLP)** and the **Naive Bayes algorithm**.

## Objective
Build a robust spam email classifier using NLP techniques and machine learning to accurately distinguish between legitimate emails and spam messages.

## Technologies Used
- Python
- Natural Language Processing (NLP)
- Pandas
- Scikit-Learn
- NLTK
- Matplotlib / Seaborn
- Jupyter Notebook

## Features
- Text preprocessing with tokenization, stop-word removal, and stemming
- TF-IDF feature extraction for converting text to numerical vectors
- Naive Bayes classification model
- Comprehensive model evaluation with accuracy, confusion matrix, and classification report
- Ability to predict new email messages

## Project Structure
```
Spam_Email_Classifier/
│
├── data/
│   └── spam_emails.csv
│
├── notebooks/
│   └── spam_email_classifier.ipynb
│
├── models/
│   └── naive_bayes_model.pkl
│
├── images/
│   └── visualizations.png
│
├── results/
│   └── evaluation_metrics.txt
│
├── README.md
│
└── requirements.txt
```

## Setup Instructions
1. Clone the repository
2. Install the required packages: `pip install -r requirements.txt`
3. Download the spam email dataset and place it in the `data/` folder
4. Run the notebook in `notebooks/spam_email_classifier.ipynb`

## Dataset
The model uses a standard spam email dataset containing columns:
- `label`: spam/ham classification
- `message`: email text content

## Model Performance
The model achieves high accuracy in classifying spam emails using:
- Text preprocessing techniques
- TF-IDF vectorization
- Multinomial Naive Bayes algorithm