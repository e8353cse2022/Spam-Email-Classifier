"""
Script to run the spam classifier from command line
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from spam_classifier import predict_email

def main():
    if len(sys.argv) < 2:
        print("Usage: python run_classifier.py \"Your email text here\"")
        print("Example: python run_classifier.py \"Congratulations! You won a free prize. Click now.\"")
        return
    
    email_text = " ".join(sys.argv[1:])
    
    result, confidence = predict_email(email_text)
    print(f"Email: '{email_text}'")
    print(f"Prediction: {result}")
    print(f"Confidence: {confidence:.2f}")

if __name__ == "__main__":
    main()