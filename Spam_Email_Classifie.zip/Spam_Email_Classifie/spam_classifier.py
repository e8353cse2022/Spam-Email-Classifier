"""
Spam Email Classifier Using NLP & Machine Learning

Objective: Build a Machine Learning model that classifies emails as 
Spam or Not Spam (Ham) using Natural Language Processing (NLP) 
and the Naive Bayes algorithm.
"""

import pandas as pd
import numpy as np
import re
import nltk
import matplotlib.pyplot as plt
import seaborn as sns

from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import pickle  # For saving the trained model
import os

def clean_text(text):
    """
    Clean the input text by:
    - Converting to lowercase
    - Removing special characters and digits
    - Removing stopwords
    - Stemming words
    """
    # Convert to lowercase
    text = text.lower()
    
    # Remove special characters and digits, keep only letters
    text = re.sub('[^a-zA-Z]', ' ', text)
    
    # Split text into words
    text = text.split()
    
    # Initialize stemmer
    ps = PorterStemmer()
    
    # Remove stopwords and stem words
    text = [ps.stem(word) for word in text if word not in stopwords.words('english')]
    
    # Join the words back into a single string
    return ' '.join(text)

def load_and_preprocess_data():
    """
    Load the dataset and perform preprocessing
    """
    # Load dataset
    data = pd.read_csv("./data/spam_emails.csv")
    print(f"Dataset shape: {data.shape}")
    
    # Label encoding: ham -> 0, spam -> 1
    data['label'] = data['label'].map({'ham': 0, 'spam': 1})
    
    # Apply text cleaning
    print("Cleaning text data...")
    data['clean_message'] = data['message'].apply(clean_text)
    
    return data

def train_model(data):
    """
    Train the Naive Bayes model
    """
    # Feature extraction using TF-IDF
    print("Extracting features using TF-IDF...")
    vectorizer = TfidfVectorizer(max_features=3000)
    X = vectorizer.fit_transform(data['clean_message']).toarray()
    y = data['label']
    
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Train the model
    print("Training the model...")
    model = MultinomialNB()
    model.fit(X_train, y_train)
    
    return model, vectorizer, X_test, y_test

def evaluate_model(model, X_test, y_test):
    """
    Evaluate the trained model
    """
    # Make predictions
    y_pred = model.predict(X_test)
    
    # Calculate accuracy
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {accuracy}")
    
    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    print(f"\nConfusion Matrix:\n{cm}")
    
    # Classification report
    print(f"\nClassification Report:\n{classification_report(y_test, y_pred)}")
    
    # Visualize Confusion Matrix
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Ham', 'Spam'], 
                yticklabels=['Ham', 'Spam'])
    plt.title('Confusion Matrix')
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.savefig('./images/confusion_matrix.png')
    plt.show()
    
    return y_pred, accuracy

def save_model(model, vectorizer):
    """
    Save the trained model and vectorizer
    """
    # Create models directory if it doesn't exist
    os.makedirs('./models', exist_ok=True)
    
    # Save model and vectorizer
    pickle.dump(model, open('./models/naive_bayes_model.pkl', 'wb'))
    pickle.dump(vectorizer, open('./models/vectorizer.pkl', 'wb'))
    print("Model and vectorizer saved successfully!")

def predict_email(email_text, model_path='./models/naive_bayes_model.pkl', 
                  vectorizer_path='./models/vectorizer.pkl'):
    """
    Predict if an email is spam or not
    """
    # Load the saved model and vectorizer
    loaded_model = pickle.load(open(model_path, 'rb'))
    loaded_vectorizer = pickle.load(open(vectorizer_path, 'rb'))
    
    # Clean the input text
    cleaned_text = clean_text(email_text)
    
    # Vectorize the text
    text_vector = loaded_vectorizer.transform([cleaned_text]).toarray()
    
    # Make prediction
    prediction = loaded_model.predict(text_vector)[0]
    prediction_proba = loaded_model.predict_proba(text_vector)[0]
    
    # Return result
    if prediction == 1:
        return "Spam", max(prediction_proba)
    else:
        return "Not Spam (Ham)", max(prediction_proba)

def save_evaluation_results(accuracy, y_test, y_pred):
    """
    Save evaluation metrics to results file
    """
    # Create results directory if it doesn't exist
    os.makedirs('./results', exist_ok=True)
    
    cm = confusion_matrix(y_test, y_pred)
    
    with open('./results/evaluation_metrics.txt', 'w') as f:
        f.write(f"Model: Multinomial Naive Bayes\n")
        f.write(f"Accuracy: {accuracy}\n\n")
        f.write(f"Confusion Matrix:\n{cm}\n\n")
        f.write(f"Classification Report:\n{classification_report(y_test, y_pred)}\n")

def main():
    """
    Main function to execute the spam email classification pipeline
    """
    print("Starting Spam Email Classification Project...")
    
    # Download required NLTK data
    nltk.download('stopwords', quiet=True)
    
    # Load and preprocess data
    data = load_and_preprocess_data()
    
    # Display a few examples of cleaned text
    print("\nOriginal message vs Cleaned message:")
    for i in range(3):
        print(f"Original: {data['message'].iloc[i][:100]}...")
        print(f"Cleaned:  {data['clean_message'].iloc[i][:100]}...")
        print()
    
    # Train the model
    model, vectorizer, X_test, y_test = train_model(data)
    
    # Evaluate the model
    y_pred, accuracy = evaluate_model(model, X_test, y_test)
    
    # Save the model
    save_model(model, vectorizer)
    
    # Save evaluation results
    save_evaluation_results(accuracy, y_test, y_pred)
    
    # Test with sample emails
    test_emails = [
        "Congratulations! You won a free prize. Click now.",
        "Hi, can we meet for lunch tomorrow?",
        "FREE ENTRY! Win big prizes now!",
        "Meeting scheduled for 3 PM today."
    ]
    
    print("\nPredictions for sample emails:")
    for email in test_emails:
        result, confidence = predict_email(email)
        print(f"Email: '{email}' -> {result} (Confidence: {confidence:.2f})")
    
    print("\nSpam Email Classification completed successfully!")
    print(f"Final Accuracy: {accuracy:.4f}")

if __name__ == "__main__":
    main()